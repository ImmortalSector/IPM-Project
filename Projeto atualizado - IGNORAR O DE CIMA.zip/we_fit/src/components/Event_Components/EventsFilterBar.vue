<template>
  Check Filter Menu from here: "https://ej2.syncfusion.com/vue/documentation/grid/filtering/""
</template>

<script>
export default {
  name: 'EventsFilterBar',
  components: {

  },
  props: {
    lastSearch : String
  }
}
</script>

<style scoped>


</style>